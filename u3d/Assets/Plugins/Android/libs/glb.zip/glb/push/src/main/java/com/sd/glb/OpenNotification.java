package com.sd.glb;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Build;
import android.support.v4.app.NotificationCompat;

import java.util.Timer;
import java.util.TimerTask;

/**
 * @author cw
 * @date 2019/2/11
 */
public class OpenNotification {

    private static NotificationManager sNotificationManager = null;
    private static Timer mTimer = null;

    public static void NotifyText(Activity currentActivity, long time, String title) {
        NotifyText(currentActivity, time, title);
    }

    public static void NotifyText(final Activity currentActivity, final long time, final String title, final String text) {
        if (sNotificationManager == null) {
            sNotificationManager = (NotificationManager) currentActivity.getSystemService(Context.NOTIFICATION_SERVICE);
        }

        TimerTask timerTask = new TimerTask() {
            @Override
            public void run() {
                Resources res = currentActivity.getResources();
                int icon = res.getIdentifier("app_icon", "drawable", currentActivity.getPackageName());

                NotificationManager manager = (NotificationManager) currentActivity.getSystemService(Context.NOTIFICATION_SERVICE);
                //为了版本兼容  选择V7包下的NotificationCompat进行构造
                NotificationCompat.Builder builder = new NotificationCompat.Builder(currentActivity);
                support26(manager, builder);
                //第一行内容  通常作为通知栏标题
                builder.setContentTitle(title);
                //第二行内容 通常是通知正文
                builder.setContentText(text);
                //可以点击通知栏的删除按钮删除
                builder.setAutoCancel(true);
                //系统状态栏显示的小图标
                builder.setSmallIcon(icon);
                /*
                //Ticker是状态栏显示的提示
                builder.setTicker("简单Notification");
                //第三行内容 通常是内容摘要什么的 在低版本机器上不一定显示
                builder.setSubText("这里显示的是通知第三行内容！");
                //ContentInfo 在通知的右侧 时间的下面 用来展示一些其他信息
                builder.setContentInfo("2");
                //number设计用来显示同种通知的数量和ContentInfo的位置一样，如果设置了ContentInfo则number会被隐藏
                builder.setNumber(2);
                //下拉显示的大图标
                builder.setLargeIcon(BitmapFactory.decodeResource(currentActivity.getResources(), icon));
                */
                Intent intent = new Intent(currentActivity, currentActivity.getClass());
                PendingIntent pIntent = PendingIntent.getActivity(currentActivity, 1, intent, 0);
                //点击跳转的intent
                builder.setContentIntent(pIntent);
                //通知默认的声音 震动 呼吸灯
                builder.setDefaults(NotificationCompat.DEFAULT_ALL);
                Notification notification = builder.build();
                manager.notify(Math.abs((int) System.currentTimeMillis()), notification);
            }
        };

        if (mTimer == null) {
            mTimer = new Timer(true);
        }
        mTimer.schedule(timerTask, time);
    }

    public static void Clear() {
        if (mTimer != null) {
            mTimer.cancel();
            mTimer = null;
        }
    }

    private static void support26(NotificationManager manager, NotificationCompat.Builder builder) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            String id = "glbChannelId";
            String name = "glbChannel";
            NotificationChannel mChannel = new NotificationChannel(id, name, NotificationManager.IMPORTANCE_LOW);
            manager.createNotificationChannel(mChannel);
            builder.setChannelId(id);
        }
    }
}
